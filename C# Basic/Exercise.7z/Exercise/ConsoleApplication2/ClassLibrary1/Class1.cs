﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ClassLibrary1
{
	public class Class1
	{
		public int a = 0;
		protected internal int b = 0;
		void A()
		{

		}
	}
}
